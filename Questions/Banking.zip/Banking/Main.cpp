#include "Functionalities.hpp"
// #include "Accounts.hpp"
#include <iostream>
#include <memory>

int main()
{
     
    try
    {
        CreateAccount();
        Withdraw();
        RollBack();
                                                   
    }
    catch (const std::exception &e)
    {
        std::cerr << e.what() << '\n';
    }

   
}