#ifndef EMPLOYEETYPE_H
#define EMPLOYEETYPE_H

enum class EmployeeType{
    FULLTIME,
    PARTTIME,
    INTERN
};

#endif // EMPLOYEETYPE_H
