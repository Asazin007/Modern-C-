#ifndef PROJECTTYPE_H
#define PROJECTTYPE_H

enum class ProjectType{
    BACKEND,
    FRONTEND
};

#endif // PROJECTTYPE_H
